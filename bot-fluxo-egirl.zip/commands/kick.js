{const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'kick',
    aliases: ['KICK'],
    category: 'Moderation',
    description: 'kick um usuário mencionado',

  
  run: async(client, message, args) => {

    if(!message.member.hasPermission("KiCK_MEMBERS")) return message.channel.send(`:x: | ${message.author} Você precisa da permissão **KICAR MEMBROS** para utilizar este comando!`)

    const membro = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    let motivo = args.slice(1).join(" ");

    if (!motivo) motivo = "sem motivo";

if (!motivo) return message.reply('Informe o motivo do kick desde usuário!');

if (!membro.bannable) return message.reply("eu não posso kickar esse usuário!");

const filter = (reaction, user) => {

    return ['✅', '❎'].includes(reaction.emoji.name) && user.id === message.author.id;

};

let msg = await message.channel

.send(`Você está prestes a Kickar **${membro.user.username}**\nMotivo: **${motivo}**\nReaja com ✅ para confirmar ou ❎ para cancelar\n15 Segundos para decisão!`);

msg.react("✅");

msg.react("❎");

msg.awaitReactions(filter, { max: 1, time: 15000, errors: ['time'] })

    .then(collected => {

const reaction = collected.first();

if (reaction.emoji.name == '✅') {

    msg.reactions.removeAll();

     msg.edit(new MessageEmbed()
     .setTitle(`Kick!`)
     .setThumbnail(membro.user.displayAvatarURL())
     .setDescription(`Kickado: ${membro.user} (\`${membro.user.id}\`)
     Motivo: \`${motivo}\`
     Por: ${message.author} (\`${message.author.id}\`) `)
     .setColor("#F8F8FF")
     .setTimestamp()
     .setFooter(message.author.tag, message.author.displayAvatarURL()));
    msg.delete({ timeout: 3000 })

    setTimeout(function() {

        membro.kick();

    }, 1000);

    } else {

        msg.reactions.removeAll();

        msg.edit("você cancelou o kick.");
        msg.delete({ timeout: 3000 })
    }
})

.catch(collected => {

    msg.reactions.removeAll();

    msg.edit("Não houve reações kick Cancelado!");
    msg.delete({ timeout: 3000 })

}); 
}
}}