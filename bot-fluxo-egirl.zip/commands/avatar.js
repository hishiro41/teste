const Discord = require("discord.js"); 

module.exports = {
    name: "avatar",
  //veja a foto de alguém

  run : async (client, message, args) => {
    message.delete().catch(O_o => {});
  let fulano = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;

  let lebs = new Discord.MessageEmbed() 
    .setColor(`#F8F8FF`) 
    .setTitle(`<:picture:867925994898616380> | Aqui está:`) 
    .setDescription(`Clique [aqui](${fulano.avatarURL({ dynamic: true, format: "png", size: 1024 })}) para baixar a imagem.`)
    .setImage(fulano.avatarURL({ dynamic: true, format: "png", size: 1024 })) 
    .setFooter(`Comando requisitado por: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));

    message.channel.send(lebs);


  }

}