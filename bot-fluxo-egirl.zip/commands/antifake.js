const alt = require("discord-anti-alt");
const account = new alt.config({
    days: 1,//Dias de conta para ser banida ou expulsa
    options: "kick"
});

let altChannel = "863191034866434078"; //Canal que vai as logs

client.on('guildMemberAdd', async member => {
    let play = account.run(member);
    let info = alt.profile(member); 
    if(play){
        
        const embed = new Discord.MessageEmbed()
        .setAuthor(info.userTag,info.avatar)
        .setColor(config.color)
        .addField("Usuário",info.username)
        .addField("ID",info.userID)
        .addField("Tempo",info.userAge)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
        .setFooter(`Atenciosamente Cidade de Deus ©`)
        .setTimestamp()
        return member.guild.channels.cache.get(altChannel).send(embed)
       
    }
})