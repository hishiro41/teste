const Discord = require('discord.js');

exports.run = async (client, message, args) => {
message.delete().catch(O_o => {});
var list = [
   'https://imgur.com/KnOmvXB.gif',
   'https://imgur.com/KyjyfRg.gif',
   'https://imgur.com/ou84YR2.gif'
      ];

var rand = list[Math.floor(Math.random() * list.length)];
let user = client.users.cache.get(args[0]);

const HelpEmbed = new Discord.MessageEmbed()
        .setColor('#F8F8FF')        
        .setTitle('Aqui está minha cental de ajuda! <:World_Wide_Web:867923387320782878>')
        .setURL('https://discord.gg/7eE6vQbXuy')        
        .addFields(
            {
                  name: 'Todos Comandos Disponiveis <:settings:866566632955314197>', 
                  value: '`cdd!config` **Configurar o registro!** \n`cdd!setentrada <#canal>` **Para o bot dar boas-vindas aos novos usúarios!**\n`sw!registra @user` **Para a equipe de registro**  \n`sw!registros` **Para vê com quantos registros você está** \n`sw!resetar-registros-all` **Para resetar todos os registros** \n`sw!setautorole` **Fazer o bot setar cargo automatimente aos novos membros**\n`sw!logs` **setar onde vai ser os canais de logs**\n`sw!adv` **Para dar advertências**\n`sw!ban @user` **Para dar ban em alguém**\n`sw!lock` **Para bloquear o chat**\n`sw!unlock` **Para desbloquear o chat**\n`sw!userinfo` **Para vê as informções do usuário**\n`sw!clear qntd` **Para limpar o chat**'
            },
                    )
        .addField('Não se procupe, mais comandos estão sendo adicionados', 'Work, work, work!')
        .setFooter(`Comando por: ${message.author.tag}`, message.author.displayAvatarURL())
  await message.channel.send(HelpEmbed);
}