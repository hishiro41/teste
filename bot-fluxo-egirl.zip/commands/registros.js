const Discord = require('discord.js');
const db = require('quick.db');
module.exports.run = (client, message, args) => {     

  let usermen = message.mentions.users.first() ||  message.guild.members.cache.get(args[0]) || message.author;
	let val = db.get(`registros_${message.guild.id}_${usermen}`);
	if (val === null) {
	val = 0
	}
	//db.add(`repvr_${usermen}_${usermen}`, 0);
	const embed = new Discord.MessageEmbed()
		.setTitle('Registros')
		.setDescription(`**🎩**・** O usuário ${usermen} contém ${val} registros.**`)
		.setColor('#F8F8FF')
	message.channel.send(embed);
};