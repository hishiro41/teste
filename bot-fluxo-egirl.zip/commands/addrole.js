const Discord = require('discord.js');

module.exports = {
    name: "addrole",
    category: "Moderation",
    aliases: ["ar", "giverole"],
    description: "Adds the role to the mentioned user or ID with mentioned role or ID !!",
    example: `t!addrole @LolaMoranguinho @Mod`,

    run: async (client, message, args) => {

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const perms = ["MANAGE_ROLES" || "ADMINSTRATOR"];
        const doggo = message.guild.members.cache.get(client.user.id);
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);

        let reason = args.slice(2).join(' ');
        if (!reason) reason = '`-`';
        if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';

        if(!message.member.hasPermission(perms)) 
        return message.reply(`**❌|Você não tem permissão tente pedir a um Admin por que você não tem permissão de ** **\`MANAGE_ROLES\`** ou **\`ADMINISTRATOR\`**`)
        .then(msg => {
            msg.delete({ timeout: 20000 })
        });

        
        if(!doggo.hasPermission(perms))
        return message.reply(`**❌| Eu não tenho permissão de dar cargo então me dê permissão de ** **\`MANAGE_ROLES\`** ou **\`ADMINSTRATOR\`** !`)

        if (!user)
        return message.reply(`**❌|Por Favor diga a pessoa que você quer dar o cargo!!** **\`sw!addrole [Usuário] [Menção do Cargo or ID do Cargo]\`**`)

        if (!role)
        return message.reply(`**❌|Mencione um cargo ou um ID válido de um cargo!**`);

        else if (user.roles.cache.has(role.id))
        return message.reply(`**❌|O Usuário ja tem o cargo**`);

        else {
            try {

                await user.roles.add(role);

                const embed = new Discord.MessageEmbed()
                .setTitle('**Cargo Adicionado!!**')
                .setColor('#F8F8FF')
                .setDescription(` ✅| ${role}(\`${role.id}\`) foi dado com sucesso a <@${user.id}>(\`${user.user.tag}\`)`)
                .addField('Dado por:', `<@${message.member.id}>\n(\`${message.member.user.tag}\`)`, true)
                .addField('Para:', `<@${user.id}>\n(\`${user.user.tag}\`)`, true)
                .addField('Cargo:', `${role}\n(\`${role.id}\`)`, true)
                .addField('Razão:', reason)
                .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
                .setTimestamp()
                .setColor(message.guild.me.displayHexColor);

                await message.channel.send(embed);
      
            } catch (err) {
            return message.reply(`**❌| Por Favor check a posição do cargo!**`, err.message);
            }
        }
    
    }      
        
}