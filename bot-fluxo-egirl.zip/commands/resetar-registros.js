
const Discord = require('discord.js')
const db = require('quick.db')
var ms = require('milliseconds'); // usei o milisseconds para transformas os milissegundos em segundos

module.exports = {
    config: {
        name: "resetar",
        aliases: ['resetar', 'resetar-tempo', 'resetar-mov'],
        description: "Ver o rank de horas.",
        example: "!rankcall",
        usage: '!rank call'
    },
    run: async (bot, message, args) => {
		
if(message.member.hasPermission('ADMINISTRATOR')){

		 } else return message.reply('você não tem permissão para executar este comando!');		 
		if(args[0] == "all"){
         let tempo_all = db.all().map(entry => entry.ID).filter(id => id.startsWith(`registros_${message.guild.id}_`))

        tempo_all.forEach(db.delete)
		
		let embed = new Discord.MessageEmbed()
		.setTitle('Resetado!')
		.setDescription(`O registros de todos os usuários do servidor foram resetados por ${message.member}!`)
		.setColor('#F8F8FF')
		
		message.channel.send(embed)
		} else {
		  
		  let embed = new Discord.MessageEmbed()
		  .setTitle('Reset!')
		  .setDescription(`selecione **"ALL"** para resetar o registros de todos os usuários!`)
		  .setColor('#F8F8FF')
		  
		  message.channel.send(embed)
        }
		
       
}}
        
