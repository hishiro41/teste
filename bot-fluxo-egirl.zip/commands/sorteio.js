const Discord = require("discord.js");
const ms = require("ms");
module.exports = {
name: "giveaway",
description: "Create a simple giveaway",
usage: "<time> <channel> <prize>",
category: "fun",
run: async (bot, message, args) => {
  message.delete().catch(O_o => {});
    if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply("Calminha, apenas moderadores e administradores deste servidor podem fazer sorteios.").then(msg => msg.delete({timeout: 5000}));
    if (!args[0]) return message.channel.send('Ei, tenta assim -> `fp!sorteio 1s/m/h/d #canal Prêmio` *Mensagem com alto delete*').then(msg => msg.delete({timeout: 15000}));
    if (
      !args[0].endsWith("s") &&
      !args[0].endsWith("m") &&
      !args[0].endsWith("h") &&
      !args[0].endsWith("d")
    )
      return message.channel.send(
        `Me diga qual o tempo do sorteio, por favor. Ex: 10s/m/h/d (*Mensagem com alto delete*)`.then(msg => msg.delete({timeout: 15000}))
      );
    if (isNaN(args[0][0])) return message.channel.send(`Isso não é um número! (*Mensagem com alto delete*)`.then(msg => msg.delete({timeout: 15000})));
    let channel = message.mentions.channels.first();
    if (!channel)
      return message.channel.send('Eu não achei o canal do sorteio. Por favor, me diga.(*Mensagem com alto delete*)').then(msg => msg.delete({timeout: 15000}));     
    let prize = args.slice(2).join(" ");
    if (!prize) return message.channel.send(`Hey, qual é o prêmio?`);
    message.channel.send(`*Eu criei o sorteio no canal: ${channel}*`).then(msg => msg.delete({timeout: 5000}));
    var gif = ('https://cdn.discordapp.com/attachments/863192433579130920/866870986054172702/sorteio_1.gif')
    let Embed = new Discord.MessageEmbed()
      .setTitle(`Novo Sorteiooo :tada: :tada:`)
      .setDescription(`**Prêmio:**  ${prize}`)
      .setTimestamp(Date.now() + ms(args[0]))
      .setColor(`#F8F8FF`)
      .setImage(`${gif}`)
      .setFooter('Clique no confete para participar do sorteio')
    let m = await channel.send(Embed);
    m.react("🎉");
    setTimeout(() => {
      if (m.reactions.cache.get("🎉").count <= 1) {
        message.channel.send(`Reactions: ${m.reactions.cache.get("🎉").count}`);
        return message.channel.send(
          `Não teve participantes suficiente. Cancelei o sorteio, eu sou mau!`
        );
      }
      let avatar = message.author.displayAvatarURL({format: 'png'});
      let winner = m.reactions.cache
        .get("🎉")
        .users.cache.filter((u) => !u.bot)
        .random();     
      let w = message.author.username      
      var winembed = new Discord.MessageEmbed()
            .setTitle('Parabéns!!!')
            .setColor(`#F8F8FF`)
            .setAuthor(`${w}`,`${avatar}`)
            .setDescription(`Você venceu o sorteio! ${winner}`)
            .addField(`Prêmio:`, `${prize}`)
            .setImage(avatar)
     message.channel.send(winembed)
    }, ms(args[0]))}};