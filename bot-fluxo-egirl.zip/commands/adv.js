const {Message, MessageEmbed}= require('discord.js')
const ms = require('ms')
const moment = require('moment');
moment.locale('pt-BR');

module.exports = {
    name : 'tempmute',
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
        message.delete()
        if(!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('Você é fraco lhe falta permissão para usar esse comando')
        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!Member) return message.channel.send('🚫 | Mencione um membro para ser advêrtido!').then(msg => msg.delete({timeout: 60000}));
        let motivo = args.slice(1).join(" ")
        if(!motivo) return message.channel.send('🚫 | Diga o motivo da advêrtencia!').then(msg => msg.delete({timeout: 60000}));
        const role1 = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'adv 1')
        const role2 = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'adv 2')
        const role3 = message.guild.roles.cache.find(role => role.name.toLowerCase() === 'adv 3')
        if(!role1) {
            try {
                message.channel.send('Os cargos de advertencia estão sendo criados no seu servidor').then(msg => msg.delete({timeout: 6000}));

                let muterole = await message.guild.roles.create({
                    data : {
                        name : 'adv 1',
                        permissions: [104189505],
                        color : '#F8F8FF'
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                    })
                });
                message.channel.send('Cargos criados com sucesso.').then(msg => msg.delete({timeout: 6000}));
            } catch (error) {
                console.log(error)
            }
        };

        if(!role2) {
            try {
                let muterole = await message.guild.roles.create({
                    data : {
                        name : 'adv 2',
                        permissions: [104189505],
                        color : '#F8F8FF'
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                    })
                });
            } catch (error) {
                console.log(error)
            }
        };

        if(!role3) {
            try {
                let muterole = await message.guild.roles.create({
                    data : {
                        name : 'adv 3',
                        permissions: [104189505],
                        color : '#F8F8FF'
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                    })
                });
            } catch (error) {
                console.log(error)
            }
        };

        const aviso = new MessageEmbed()
        .setTitle("🚨 | Advêrtecia")
        .setThumbnail(Member.user.displayAvatarURL({ dynimc: true }))
        .addField("<:Users:866839868419342347> | Membro:", `> ${Member}`, true)
        .addField("<:id_CDN:862553680145416222> | Advêrtido por:", `> ${message.author}`, true)
        .addField("<:Alert:866840072178499614> | Advertencia:", '> **1**/3', true)
        .addField("✍ | Motivo:", `\`\`\`${motivo}\`\`\``)
        .setFooter(`${client.user.username}`,client.user.displayAvatarURL({dinamyc : true}))
        .setTimestamp(new Date())
        .setColor("#F8F8FF")

        const aviso2 = new MessageEmbed()
        .setTitle("🚨 | Advêrtecia")
        .setThumbnail(Member.user.displayAvatarURL({ dynimc: true }))
        .addField("<:Users:866839868419342347> | Membro:", `> ${Member}`, true)
        .addField("<:id_CDN:862553680145416222> | Advêrtido por:", `> ${message.author}`, true)
        .addField("<:Alert:866840072178499614> | Advertencia:", '> **2**/3', true)
        .addField("✍ | Motivo:", `\`\`\`${motivo}\`\`\``)
        .setFooter(`${client.user.username}`,client.user.displayAvatarURL({dinamyc : true}))
        .setTimestamp(new Date())
        .setColor("#F8F8FF")

        const aviso3 = new MessageEmbed()
         .setTitle("🚨 | Auto banimento")
        .setThumbnail(Member.user.displayAvatarURL({ dynimc: true }))
        .addField("<:Users:866839868419342347> | Membro:", `> ${Member}`, true)
        .addField("<:id_CDN:862553680145416222> | Advêrtido por:", `> ${message.author}`, true)
        .addField("<:Alert:866840072178499614> | Advertencia:", '> **3**/3', true)
        .addField("✍ | Motivo:", `\`\`\`${motivo}\`\`\``)
        .setFooter(`${client.user.username}`,client.user.displayAvatarURL({dinamyc : true}))
        .setTimestamp(new Date())
        .setColor("#F8F8FF")
    
        let role4 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'adv 1')
        let role5 = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'adv 2')
        if(Member.roles.cache.has(role5.id)) return (Member.ban(), message.channel.send(aviso3), Member.send(`${Member} você foi banido de ${message.guild.name}`, aviso3))
        if(Member.roles.cache.has(role4.id)) return (Member.roles.add(role5), message.channel.send(aviso2))
        await Member.roles.add(role4)
        message.channel.send(aviso)
    }
}