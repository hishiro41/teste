const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  config: {
      name: "autorole",
      aliases: ['al'],
      description: "cargo automatico, ativa quando um novo membro entra no servidor",
      example: "h!autorole <@role>",
      usage: 'h!autorole <@role>'
  },
  run: async (bot, message, args) => {

    let role = message.mentions.roles.first();
      message.delete({ timeout: 0})

          const embed = new Discord.MessageEmbed()
          .setColor('#000001')
          .setDescription(`${message.author} \n Você não possui permissão de \`Administrador\` para executar esse comando!`)
          if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(embed).then(msg => msg.delete({ timeout: 20000 }))

        const embed2 = new Discord.MessageEmbed()
        .setColor("#000001")
        .setDescription(`Eu não tenho permissão de \`Adimistrador\` por favor set a permissão em mim e tente novamente`)
      if (!message.guild.me.hasPermission("ADMISTRATOR")) return message.channel.send(embed2).then(msg => msg.delete({ timeout: 20000 }))
        
          const embed3 = new Discord.MessageEmbed()
          .setColor('#000001')
          .setDescription(`${message.author} \n Informe qual cargo você deseja por no autorole`)
          if(!role) return message.channel.send(embed3).then(msg => msg.delete({ timeout: 20000 }))

        db.set(`setrole_${message.guild.id}`, role.id)
        message.channel.send(`\`O cargo\` ${role} \`foi setado com sucesso!\``).then(msg => msg.delete({ timeout: 20000 }))

  } 
}