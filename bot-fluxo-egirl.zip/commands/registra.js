const Discord = require('discord.js');
const db = require('quick.db');
 
module.exports.run = async (client, message, args) => { //by gabriel
 
    let cargo_masculino_config = db.get(`registro_masculino_${message.guild.id}`);
    let cargo_feminino_config = db.get(`registro_feminino_${message.guild.id}`);
    let cargo_naobinario_config = db.get(`registro_naobinario_${message.guild.id}`);
    let cargo_mais18_config = db.get(`registro_mais18_${message.guild.id}`);
    let cargo_menos18_config = db.get(`registro_menos18_${message.guild.id}`);
    let cargo_hetero_config = db.get(`registro_hetero_${message.guild.id}`);
    let cargo_lgbt_config = db.get(`registro_lgbt_${message.guild.id}`);
    let cargo_solteiro_config = db.get(`registro_solteiro_${message.guild.id}`);
    let cargo_namorando_config = db.get(`registro_namorando_${message.guild.id}`);
    let cargo_casado_config = db.get(`registro_casado_${message.guild.id}`);
    let cargo_equiperegistro_config = db.get(`registro_equipe_${message.guild.id}`);
    let cargo_naoregistrado_config = db.get(`registro_naoregistrado_${message.guild.id}`);
    let cargo_registrado_config = db.get(`registro_registrado_${message.guild.id}`);
    let cargo_logschannel_config = db.get(`registro_logs_${message.guild.id}`);


  let registro = {
    equiperegistro: cargo_equiperegistro_config,
    naoregistrado: cargo_naoregistrado_config,
    registrado: cargo_registrado_config,
    logschannel: cargo_logschannel_config,
    masculino: cargo_masculino_config,
    feminino: cargo_feminino_config,
    naobinario: cargo_naobinario_config,
    mais18: cargo_mais18_config,
    menos18: cargo_menos18_config,
    hetero: cargo_hetero_config,
    lgbt: cargo_lgbt_config,
    solteiro: cargo_solteiro_config,
    namorando: cargo_namorando_config,
    casado: cargo_casado_config,
  };
 
  let page = 1;
  let pages = new Array();
 
  if (!message.member.roles.cache.has(registro.equiperegistro)) return message.channel.send(`:x: | ${message.author} Você não é da esquipe de registro!`);
  message.delete();
  let cargos = [];
  let pv = [];
  let masculino = message.guild.roles.cache.get(registro.masculino)
  let feminino = message.guild.roles.cache.get(registro.feminino)
  let naobinario = message.guild.roles.cache.get(registro.naobinario)
  let menos18 = message.guild.roles.cache.get(registro.menos18)
  let mais18 = message.guild.roles.cache.get(registro.mais18)
  let hetero = message.guild.roles.cache.get(registro.hetero)
  let lgbt = message.guild.roles.cache.get(registro.lgbt)
  let solteiro = message.guild.roles.cache.get(registro.solteiro)
  let namorando = message.guild.roles.cache.get(registro.namorando)
  let casado = message.guild.roles.cache.get(registro.casado)
  let userReg = message.mentions.users.first();
  let member = message.guild.member(userReg);
  if (!userReg) return message.channel.send(`:x: | ${message.author} Mencione um usuário para registrar!`);
 //ferinha
  pages.push({
    description: `**Registrado:** ${userReg}\n**Registrador:** ${message.author}\n\n` +
      `**Qual sua sexualidade?**\n<a:dn_numero1_dkw:867924773919924245> ${masculino}\n<a:dn_numero2:867924796166508554> ${feminino}\n<a:dn_numero3:867924813652570132> ${naobinario}\n\n`,
    cargos: [
      masculino,
      feminino,
      naobinario
    ]
  });
  pages.push({
    description: `**Registrado:** ${userReg}\n**Registrador:** ${message.author}\n\n` +
      `**Qual sua idade?**\n<a:dn_numero1_dkw:867924773919924245> ${menos18}\n<a:dn_numero2:867924796166508554> ${mais18}\n\n`,
    cargos: [
      menos18,
      mais18
    ]
  });
  pages.push({
    description: `**Registrado:** ${userReg}\n**Registrador:** ${message.author}\n\n` +
      `**Qual o seu gênero?**\n<a:dn_numero1_dkw:867924773919924245> ${hetero}\n<a:2T:849144424805826571> ${lgbt}\n\n`,
    cargos: [
      hetero,
      lgbt
    ]
  });
  pages.push({
    description: `**Registrado:** ${userReg}\n**Registrador:** ${message.author}\n\n` +
      `**Qual seu estado cívil?**\n<a:dn_numero1_dkw:867924773919924245> ${namorando}\n<a:dn_numero2:867924796166508554> ${solteiro}\n<a:dn_numero3:867924813652570132> ${casado}\n\n`,
    cargos: [
      namorando,
      solteiro,
      casado
    ]
  });
 //ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha//ferinha
  const embed = new Discord.MessageEmbed()
    .setColor('#F8F8FF')
    .setDescription(pages[page - 1].description)
    .setFooter('Registrador');
 
  const embedUser = new Discord.MessageEmbed()
    .setTitle('Você foi registrado(a)!')
    .setColor('#F8F8FF')
    .setThumbnail(message.guild.iconURL({ dynamic: true }))
    .setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n`+
      `**Cargos recebidos:** ${pv!==''?'nenhum.':pv.join(', ')}`)
    .setFooter(`ID: \`${userReg.id}\``)
    .setTimestamp();
 
  const embedFinish = new Discord.MessageEmbed()
    .setTitle('Registro efetuado!')
    .setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
      `**Cargos recebidos:** ${pv!==''?'nenhum.':pv.join(', ')}`)
    .setColor('#F8F8FF')
    .setThumbnail(userReg.displayAvatarURL())
    .setFooter('Registros | ' + message.guild.name)

  message.channel.send(embed).then(msg =>
    msg.react('1️⃣').then(r => {
      msg.react('2️⃣');
      msg.react('3️⃣');
      msg.react('➡');
 
      const oneFilter = (reaction, user) => reaction.emoji.name === '1️⃣' && user.id === message.author.id;
      const twoFilter = (reaction, user) => reaction.emoji.name === '2️⃣' && user.id === message.author.id;
      const threeFilter = (reaction, user) => reaction.emoji.name === '3️⃣' && user.id === message.author.id;
      const forwardsFilter = (reaction, user) => reaction.emoji.name === '➡' && user.id === message.author.id;
 
      const one = msg.createReactionCollector(oneFilter, { time: 60000 });
      const two = msg.createReactionCollector(twoFilter, { time: 60000 });
      const three = msg.createReactionCollector(threeFilter, { time: 60000 });
      const forwards = msg.createReactionCollector(forwardsFilter, { time: 60000 });
 //ferinha//ferinha kkkjkjkj sla :>
      one.on('collect', async (r, user) => {
        member.roles.add(pages[page - 1].cargos[0]);
        cargos.push(pages[page - 1].cargos[0]);
        pv.push(pages[page - 1].cargos[0].name);
        r.users.remove(user);
        if (page === pages.length) {
          embedFinish.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          message.channel.send(embedFinish);
          embedUser.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          userReg.send(embedUser);
          member.roles.add(registro.registrado);
          member.roles.remove(registro.naoregistrado);
          client.channels.cache.get(registro.logschannel).send(embedFinish);
          db.add(`registros_${message.guild.id}_${message.author}`, 1)
          msg.delete();
          return;
        }
        page++;
        embed.setDescription(pages[page - 1].description +
          `**Cargos recebidos:**\n${pv.length===0?'nenhum':pv.join(', ')}`);
        msg.edit(embed);
      });
 
      two.on('collect', async (r, user) => {
        member.roles.add(pages[page - 1].cargos[1]);
        cargos.push(pages[page - 1].cargos[1]);
        pv.push(pages[page - 1].cargos[1].name);
        r.users.remove(user);
        if (page === pages.length) {
          embedFinish.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          message.channel.send(embedFinish);
          embedUser.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          userReg.send(embedUser);
          member.roles.add(registro.registrado);
          member.roles.remove(registro.naoregistrado);
          client.channels.cache.get(registro.logschannel).send(embedFinish);
          db.add(`registros_${message.guild.id}_${message.author}`, 1)
          msg.delete();
          return;
        }
        page++;
        embed.setDescription(pages[page - 1].description +
          `**Cargos recebidos:**\n${pv.length===0?'nenhum':pv.join(', ')}`);
        msg.edit(embed);
      });
 
      three.on('collect', async (r, user) => {
        member.roles.add(pages[page - 1].cargos[2]);
        cargos.push(pages[page - 1].cargos[2]);
        pv.push(pages[page - 1].cargos[2].name);
        r.users.remove(user);
        if (page === pages.length) {
          embedFinish.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          message.channel.send(embedFinish);
          embedUser.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          userReg.send(embedUser);
          member.roles.add(registro.registrado);
          member.roles.remove(registro.naoregistrado);
          client.channels.cache.get(registro.logschannel).send(embedFinish);
          db.add(`registros_${message.guild.id}_${message.author}`, 1)
          msg.delete();
          return;
        }
        page++;
        embed.setDescription(pages[page - 1].description +
          `**Cargos recebidos:**\n${pv.length===0?'nenhum':pv.join(', ')}`);
        msg.edit(embed);
      });
 
      forwards.on('collect', async (r, user) => {
        r.users.remove(user);
        if (page === pages.length) {
          embedFinish.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          message.channel.send(embedFinish);
          embedUser.setDescription(`**Registrador:** ${message.author}\n**Registrado:** ${userReg}\n\n` +
            `**Cargos recebidos:** ${pv.length===0?'nenhum':pv.join(', ')}`);
          userReg.send(embedUser);
          member.roles.add(registro.registrado);
          member.roles.remove(registro.naoregistrado);
          client.channels.cache.get(registro.logschannel).send(embedFinish);
          db.add(`registros_${message.guild.id}_${message.author}`, 1)
          msg.delete();
          return;
        }
        page++;
        embed.setDescription(pages[page - 1].description +
          `**Cargos recebidos:**\n${pv.length===0?'nenhum':pv.join(', ')}`);
        msg.edit(embed);
      });
 
    })
  );
 
}